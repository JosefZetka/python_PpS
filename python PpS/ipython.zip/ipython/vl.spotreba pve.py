import pandas as pd
import matplotlib.pyplot as plt
# nacteni celeho filu
file = pd.read_excel('c:\\Users\\josef\\Desktop\\toDelete\\Sestavy Přečerpávačky + Vltava.xlsm','EDS')
# vytvoreni velicin
zc_odch = pd.to_numeric(file['ZC_odchylka'].drop(file['ZC_odchylka'].index[0]), errors='coerce')
zc_protiodch = pd.to_numeric(file['ZC_protiodchylka'].drop(file['ZC_protiodchylka'].index[0]), errors='coerce')
vypvlspotr = pd.to_numeric(file['vypoctena'].drop(file['vypoctena'].index[0]), errors='coerce')
skutvlspotr = pd.to_numeric(file['Skutecna vl.sp.'].drop(file['Skutecna vl.sp.'].index[0]), errors='coerce')
rozdilspotr = pd.to_numeric(file['Rozdil'].drop(file['Rozdil'].index[0]), errors='coerce')
vyproz = vypvlspotr + skutvlspotr
delta = vyproz - rozdilspotr

# vytvoreni grafu
plt.figure();
#%matplotlib inline
zc_odch.plot.hist(bins=50, alpha=0.5)
zc_protiodch.plot.hist(bins=50, alpha=0.5)
plt.xlabel('cena')
plt.ylabel('Četnost')
plt.show()
plt.figure();
#%matplotlib inline
vypvlspotr.plot.hist(bins=50, alpha=0.5)
skutvlspotr.plot.hist(bins=50, alpha=0.5)
plt.show()

plt.figure();
#%matplotlib inline
rozdilspotr.plot.hist(bins=50, alpha=0.5)
plt.show()
file.iloc[5,:]
