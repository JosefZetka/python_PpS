def bqf(a,b,c):
    return lambda x: a*x**2+b*x+c

f = bqf(2,500,1000)
print(f(0))
print(f(100))
print(f(200))

planets = [
    ("Mercury",2440, 3.285, 0, 0.13, 3.59),
    ("Venus",6052, 4.867, 0, 0, 8.87),
    ("Earth",6371, 5.972, 7530000000, 20.95, 9.81),
    ("Mars",3390, 6.39, 0, 0.146, 3.77)
        ]
size = lambda planet: planet[4]
planets.sort(key=size)
print(planets)