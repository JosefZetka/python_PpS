class blok:
    def __init__(self,**kwargs):
        self.elna=elna
        self.unit=unit
        self.pr=pr
        self.srp=srp
        self.srm=srm
        self.mz15p=mz15p
        self.mz15m=mz15m
        self.max1=max1
        self.min1=min1
        self.max2=max2
        self.min2=min2
        self.pmintech=pmintech
        self.pmaxtech=pmaxtech
        self.cmaxtech=cmaxtech
        self.cmaxnorm=cmaxnorm
        self.cmaxdo=cmaxdo
        self.prpret=prepret
        self.prpodtizeni=prpodtizeni
        self.pn=pn


