from unit import unit
import pandas as pd 
cer = pd.read_csv('certifikat.csv')
lcer=cer.columns
u_cer=[]
#Elna,Unit,PR,SRP,SRM,MZ15P,MZ15M,Max1,Min1,Max2,Min2,Pmintech,Pmaxtech,cmaxtech,cmaxnorm,cmaxdo,PRpret,PRpodtizeni,Pn
# 0     1   2   3   4   5   6       7   8     9     10  11      12          13      14      15      16      17       18
def nacteni_cer():
    for i in range(len(cer.index)):
        b_cer= unit()
        b_cer.pr = cer.iloc[[i],[2]]
        b_cer.elna = cer.iloc[[i],[0]]
        b_cer.unit = cer.iloc[[i],[1]]
        b_cer.srp = cer.iloc[[i],[3]]
        b_cer.srm = cer.iloc[[i],[4]]
        b_cer.mz15p= cer.iloc[[i],[5]]
        b_cer.mz15m= cer.iloc[[i],[6]]
        b_cer.Max1= cer.iloc[[i],[7]]
        b_cer.Min1= cer.iloc[[i],[8]]
        b_cer.Max2= cer.iloc[[i],[9]]
        b_cer.Min2= cer.iloc[[i],[10]]
        b_cer.Pmintech= cer.iloc[[i],[11]]
        b_cer.Pmaxtech= cer.iloc[[i],[12]]
        b_cer.cmaxtech= cer.iloc[[i],[13]]
        b_cer.cmaxnorm= cer.iloc[[i],[14]]
        b_cer.cmaxdo= cer.iloc[[i],[15]]
        b_cer.PRpodtizeni= cer.iloc[[i],[16]]
        b_cer.PRpret= cer.iloc[[i],[17]]
        b_cer.Pn= cer.iloc[[i],[18]]
        u_cer.append(b_cer)
print(u_cer[0].unit)