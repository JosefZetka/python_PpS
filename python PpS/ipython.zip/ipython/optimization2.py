
from pulp import LpProblem, LpVariable, lpSum, LpMaximize,value,LpBinary
prob = LpProblem("Dedication Model",LpMaximize)
pr1 = LpVariable("pr1", 0, None)
d1 = LpVariable("d1",0,1,LpBinary)
d2 = LpVariable("d2",0,1,LpBinary)
srp1 = LpVariable("srp1", 0, None)
srm1 = LpVariable("srm1", 0, None)
pdg1 = LpVariable("pdg1",0,None)
pr2 = LpVariable("pr2", 0, None)
srp2 = LpVariable("srp2", 0, None)
srm2 = LpVariable("srm2", 0, None)
pdg2 = LpVariable("pdg2",0,None)
prob += 1*pr1 + 5*pr2 + 3*srp1 + 3*srp2 + 2*srm1 + 2*srm2 + pdg1 + pdg2 
prob += pr1 >= d1*5
prob += pr1 <= d1*10
prob += pr2 >= d2*5
prob += pr2 <= d2*10
prob += srp1 >= 10
prob += srp1 <= 30
prob += srp2 >= 10
prob += srp2 <= 30
prob += srm1 >= 10
prob += srm1 <= 30
prob += srm2 >= 10
prob += srm2 <= 30
prob += pdg1 + pr1 + srp1  <= 200
prob += pdg2 + pr2 + srp2  <= 200
prob += pdg1 - pr1 - srm1  >= 120
prob += pdg2 - pr2 - srm2  >= 120

prob.solve()

#print 'optimal total cost is:',value(prob.objective)
print ("pr1 :" + str(pr1.varValue))
print ("srp1 :" + str(srp1.varValue))
print ("srm1 :" + str(srm1.varValue))
print ("pdg1 :" + str(pdg1.varValue))
print ("pr2 :" + str(pr2.varValue))
print ("srp2 :" + str(srp2.varValue))
print ("srm2 :" + str(srm2.varValue))
print ("pdg2 :" + str(pdg2.varValue))
#print "X2 :", X2.varValue

def pokus():
    even = [i for i in [1,2,3,4,5,6] if i%2 == 0]
    print(even)

pokus()