# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
class Person:
    def __init__ (self,jmeno,primeni,vek,bmi):
        self.jmeno=jmeno
        self.primeni=primeni
        self.vek=vek
        self.bmi=bmi
        
        
    
