class unit:
    def __init__(self, **kwargs):
        self.pdg=kwargs.get('pdg',"0")
        self.pr=kwargs.get('pr',"0") 
        self.srp=kwargs.get('srp',"0")
        self.srm=kwargs.get('srm',"0")
        self.mz15p=kwargs.get('mz15p',"0")
        self.mz15m=kwargs.get('mz15m',"0")
        self.Max1=kwargs.get('max1',"0")
        self.Min1 = kwargs.get('min1',"0")
        self.Max2 = kwargs.get('max2',"0")
        self.Min2 = kwargs.get('min2',"0")
        self.Pmintech = kwargs.get('pmintech',"0")
        self.Pmaxtech = kwargs.get('pmaxtech',"0")
        self.cmaxtech = kwargs.get('cmaxtech',"0")
        self.cmaxnorm = kwargs.get('cmaxnorm',"0")
        self.cmaxdo = kwargs.get('cmaxdo',"0")
        self.PRpret = kwargs.get('prpret',"0") 
        self.PRpodtizeni = kwargs.get('prpod',"0")
        self.Pn = kwargs.get('pn',"0") 
        self.elna = kwargs.get('elna',"0") 
        self.unit = kwargs.get('unit',"0") 


