# -*- coding: utf-8 -*-
import pandas as pd
from mypack import blok
from csv import*
from unit import unit 
import datetime as dt
#global u_cer
u_cer=[]
nacteni_certifikatu()

def nacteni_certifikatu():
    cer = pd.read_csv('certifikat.csv')
    lcer=cer.columns
    
    for i in range(len(cer.index)):
        b_cer= unit()
        b_cer.pr = cer.iloc[[i],[2]]
        b_cer.elna = cer.iloc[[i],[0]]
        b_cer.unit = cer.iloc[[i],[1]]
        b_cer.srp = cer.iloc[[i],[3]]
        b_cer.srm = cer.iloc[[i],[4]]
        b_cer.mz15p= cer.iloc[[i],[5]]
        b_cer.mz15m= cer.iloc[[i],[6]]
        b_cer.Max1= cer.iloc[[i],[7]]
        b_cer.Min1= cer.iloc[[i],[8]]
        b_cer.Max2= cer.iloc[[i],[9]]
        b_cer.Min2= cer.iloc[[i],[10]]
        b_cer.Pmintech= cer.iloc[[i],[11]]
        b_cer.Pmaxtech= cer.iloc[[i],[12]]
        b_cer.cmaxtech= cer.iloc[[i],[13]]
        b_cer.cmaxnorm= cer.iloc[[i],[14]]
        b_cer.cmaxdo= cer.iloc[[i],[15]]
        b_cer.PRpodtizeni= cer.iloc[[i],[16]]
        b_cer.PRpret= cer.iloc[[i],[17]]
        b_cer.Pn= cer.iloc[[i],[18]]
        u_cer.append(b_cer)

        
 
def maxsrp(**kwargs):
    pdg = kwargs.get('pdg',"0")
    pr=kwargs.get('pr','0')
    mz15p=kwargs.get('mz15p',"0")
    mz15m=kwargs.get('mz15m',"0")
    srm=kwargs.get('srm',"0")
    max1=kwargs.get('max1',"0")
    min1=kwargs.get('min1',"0")
    if max1>min1 and max1>pdg and pdg>min1:
        dsrp = max1 - min1
        if int(dsrp) > int(u_cer[0].srp.SRP[0]):
            maxsrp = int(u_cer[0].srp.SRP[0])
        else:
            maxsrp = int(dsrp)
        return maxsrp


    



