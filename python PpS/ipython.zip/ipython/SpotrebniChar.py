# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 09:39:28 2019

@author: josef
"""

class SpotChar:
    def __init__(self,name,a0,a1,a2,pmax,pmin):
        self.a0=a0
        self.a1=a1
        self.a2=a2
        self.name=name
        self.pmax=pmax
        self.pmin=pmin
        self.v=(self.cost(self.pmax)/self.pmax)

    def cost(self,p):
        return self.a0+self.a1*p+self.a2*p*p

    def AvrCost(self):
        return self.cost(self.pmax)/self.pmax




#    def info(self):
#        print("Nacteno: a0 " +  self.a0 + ", a1 = " + self.a1 + " a2 = " + self.a2 )
#    def make_SpotChar(name,a0,a1,a2)
#        make_SpotChar=SpotChar(name,a0,a1,a2)
#        return Spotchar
