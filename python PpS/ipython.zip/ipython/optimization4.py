from pulp import LpProblem,LpMaximize,LpVariable,LpBinary,lpSum, LpStatus

NAME = ['EPC2','EPC3','EPC4','EPC5','EPC6']
LOCATIONS = [0,1,2,3,4]
Pmin = [120,160,120,120,120]
Pmax = [200,200,200,200,200]
SRPmin = [10,10,10,10,10]
SRPmax = [30,30,30,30,30]
SRMmin = [10,10,10,10,10]
SRMmax = [30,30,30,30,30]

prob = LpProblem("SR",LpMaximize)
#use_vars = LpVariable.dicts("uselocation",LOCATIONS,0,1,LpBinary)
pdg_vars = LpVariable.dicts("Pdg",LOCATIONS,0,200)
x_vars = LpVariable.dicts("uselocation",LOCATIONS,0, 1, LpBinary)
srp_vars = LpVariable.dicts("SRP",LOCATIONS,0,40)
srm_vars = LpVariable.dicts("SRM",LOCATIONS,0,40)
prob +=lpSum(srp_vars[i]+srm_vars[i] for i in LOCATIONS)

for i in LOCATIONS:
    prob +=pdg_vars[i]-srm_vars[i] + srp_vars[i] >= Pmin[i] * x_vars[i]
    prob +=pdg_vars[i] -srm_vars[i] + srp_vars[i] <=Pmax[i] * x_vars[i]
    prob +=srp_vars[i] >= SRPmin[i] * x_vars[i]
    prob +=srp_vars[i] <= SRPmax[i] * x_vars[i]
    prob +=srm_vars[i] >= SRPmin[i] * x_vars[i]
    prob +=srm_vars[i] <= SRPmax[i] * x_vars[i]
    prob +=pdg_vars[i] >= Pmin[i] * x_vars[i]
    prob +=pdg_vars[i] <=Pmax[i] * x_vars[i]
     
prob += lpSum(srp_vars[i] for i in LOCATIONS) == 100
prob += lpSum(srm_vars[i] for i in LOCATIONS) == 100
prob += lpSum(pdg_vars[i] for i in LOCATIONS) == 500
prob += x_vars[0] == 1

status = prob.solve()
#prob.solve()
print("Status:", LpStatus[prob.status])
TOL = 0.01
for i in LOCATIONS:
    print("TG{0} ma Pdg = {1}, SRP = {2}, SRM = {3} a status {4}".format(i,pdg_vars[i].varValue,srp_vars[i].varValue,srm_vars[i].varValue,x_vars[i].varValue))

