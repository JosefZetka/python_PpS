# -*- coding: utf-8 -*-
"""
Created on Wed May 29 20:59:17 2019

@author: dell
"""

class Persons(object):
    def __init__(self, number):
        self.number = number
