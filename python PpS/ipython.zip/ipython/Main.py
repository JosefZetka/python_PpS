import Kotel
Kotel.nacteni_certifikatu()
i=0
for u in Kotel.u_cer:
    print(str(u.unit),sep='')
    print(str(u.pr), sep=' ')
    print(str(u.srp), sep=' ')
    print(str(u.srm), sep=' ')
    print(str(u.mz15p), sep=' ')
    print(str(u.mz15m), sep=' ')
    print(str(u.PRpret), sep=' ')
    print(str(u.PRpodtizeni), sep=' ')
    print(str(u.Max1), sep=' ')
    print(str(u.Min1))

if str(Kotel.u_cer[3].unit) == 'TG5':
    print("To je chyba, {0} neni TG5".format(Kotel.u_cer[3].unit))
else:
    print("Je to OK, unit je {0}".format(Kotel.u_cer[3].unit))

print("MaxSRP: " + str(Kotel.maxsrp(max1=200,min1=160,pdg=180)))

