import pandas as pd
import os
from SpotrebniChar import SpotChar as sp
import logging, sys
logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

import numpy as np
from collections import defaultdict
import datetime as dt

NameOfSheets=pd.ExcelFile(r'C:\Users\josef\PycharmProjects\Tutorial1\Provozni parametry.xlsx').sheet_names

ProvPar=pd.read_excel(r'C:\Users\josef\PycharmProjects\Tutorial1\Provozni parametry.xlsx',sheetname=NameOfSheets[2])
MaxMin=pd.read_excel(r'C:\Users\josef\PycharmProjects\Tutorial1\Provozni parametry.xlsx',sheetname=NameOfSheets[0])

listbloku=list()
PP=ProvPar.dropna()
MM=MaxMin['Výkonové meze Tg (k datu 6. 6. 2019)'].dropna()
for i in range(0,len(PP)):
#        name=PP['Charakteristiky (k datu 6. 6. 2019)'].iloc[i]
        _a0=PP['Unnamed: 2'].iloc[i]
        _a1=PP['Unnamed: 3'].iloc[i]
        _a2=PP['Unnamed: 4'].iloc[i]
        _name=PP['Charakteristiky (k datu 6. 6. 2019)'].iloc[i]
        _pmax=200
        _pmin=90
        blok=sp(_name,_a0,_a1,_a2,_pmax,_pmin)
        listbloku.insert(i,blok)

for i in range(len(MaxMin)):
    for j in range(len(listbloku)):
        if str(MaxMin['Výkonové meze Tg (k datu 6. 6. 2019)'].iloc[i]) == str(listbloku[j].name):
            listbloku[j].pmax=MaxMin['Unnamed: 2'].iloc[i]




listbloku.sort(key=sp.AvrCost,reverse=False)

print(str(dt.datetime.now()))

for b in listbloku:
    b.AvrCost()
    print(" b.avrcost = " + str(b.AvrCost()) + "b.name = "                 + str(b.name) + ", b.pmax = " + str(b.pmax) )


