from Kotel import nacteni_certifikatu as nc  
nc.__init__()
nc()
print(nc.u_cer)



